/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package edicaodojogozuul.controller;

import edicaodojogozuul.model.Jogo;

/**
 *
 * @author devsousa
 */
public class Programa {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
	Jogo jogo = new Jogo();
		
	jogo.jogar();
    }

    
}
