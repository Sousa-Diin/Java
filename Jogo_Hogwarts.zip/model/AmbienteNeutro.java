
package edicaodojogozuul.model;

/**
 *
 * @author Wildes Sousa
 */
public class AmbienteNeutro extends Ambiente{

    public AmbienteNeutro(String descricao, String id) {
        super(descricao, id);
    }
    
    
    
}
